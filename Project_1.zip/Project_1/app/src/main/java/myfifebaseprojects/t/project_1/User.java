package myfifebaseprojects.t.project_1;

/**
 * Created by Shiv on 2/23/17.
 */

public class User {
    String email;
    String img;
    public User(String x, String y) {
        email = x;
        img = y;
    }
}
